import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-progressmonitoring',
  templateUrl: './progressmonitoring.page.html',
  styleUrls: ['./progressmonitoring.page.scss'],
})
export class ProgressmonitoringPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guiding-principles',
  templateUrl: './guiding-principles.page.html',
  styleUrls: ['./guiding-principles.page.scss'],
})
export class GuidingPrinciplesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

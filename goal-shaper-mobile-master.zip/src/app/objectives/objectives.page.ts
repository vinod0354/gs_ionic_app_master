import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-objectives',
  templateUrl: './objectives.page.html',
  styleUrls: ['./objectives.page.scss'],
})
export class ObjectivesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
